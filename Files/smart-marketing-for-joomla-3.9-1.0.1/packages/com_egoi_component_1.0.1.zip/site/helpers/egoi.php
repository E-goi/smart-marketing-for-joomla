<?php

/**
 * @version     1.0.1
 * @package     com_egoi
 * @copyright   Copyright (C) 2015. Todos os direitos reservados.
 * @license     GNU General Public License versão 2 ou posterior; consulte o arquivo License. txt
 * @author      Marcio Pati Caldeira de Andrada <gaia@esinow.net> - http://esinow.net
 */
defined('_JEXEC') or die;

class EgoiFrontendHelper {
    
}
