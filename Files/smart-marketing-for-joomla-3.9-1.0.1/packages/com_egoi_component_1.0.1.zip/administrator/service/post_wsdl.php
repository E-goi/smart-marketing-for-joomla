<?php
$options = array(
	'location' => 'http://plugins-reports.e-goi.com/internal/egoi/service.php', 
    'uri' => 'http://plugins-reports.e-goi.com/'
);