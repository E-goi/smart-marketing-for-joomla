DROP TABLE IF EXISTS `#__egoi`;
DROP TABLE IF EXISTS `#__egoi_forms`;
DROP TABLE IF EXISTS `#__egoi_map_fields`;
DROP TABLE IF EXISTS `#__virtuemart_egoi`;

DELETE FROM `#__extensions` WHERE `element` = 'egoi';