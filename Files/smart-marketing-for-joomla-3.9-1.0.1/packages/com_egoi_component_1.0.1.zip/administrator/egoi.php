<?php
ini_set('display_errors', 1);
error_reporting(E_ALL & ~E_NOTICE);
/**
 * @version     1.0.1
 * @package     com_egoi
 * @copyright   Copyright (C) 2016. Todos os direitos reservados.
 * @license     GNU General Public License versão 2 ou posterior; consulte o arquivo License. txt
 * @author      E-goi - https://www.e-goi.com
 */
// no direct access
defined('_JEXEC') or die;
// Include dependancies
jimport('joomla.application.component.controller');
$controller	= JControllerLegacy::getInstance('Egoi');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
