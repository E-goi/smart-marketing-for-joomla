<?php
/**
 * @version     1.0.1
 * @package     com_egoi
 * @copyright   Copyright (C) 2016. Todos os direitos reservados.
 * @license     GNU General Public License versão 2 ou posterior; consulte o arquivo License. txt
 * @author      E-goi
 */

// no direct access
defined('_JEXEC') or die;

JHtml::_('behavior.formvalidation');
$data = $this->viewData;
?>

	<style> 
		label {
			display: inline !important;
		}
	</style>

	<script type="text/javascript">
		jQuery(document).ready(function ($){
			$('.btn-toolbar').append('<a href="//bo.e-goi.com/?from=<?php echo urlencode('/?action=dados_cliente&menu=sec');?>" target="_blank" class="btn btn-primary" id="egoi_edit_info"><?php echo JText::_('EGOI_CHANGE_DATA');?></a><span class="egoi-redirect"> <?php echo JText::_('EGOI_CHANGE_DATA_INFO');?></span>');
		}(jQuery));

		function saveApiKeyAndReload() {
			if (document.forms["adminForm"].elements['apikey_disp'].value != "<?php echo $data['apikey'];?>") {
				document.forms["adminForm"].elements['apikey'].value = document.forms["adminForm"].elements['apikey_disp'].value;

				document.getElementById('input_key').style.display = 'none';
				document.getElementById('content_key').style.display = 'inline-block';
				document.forms["adminForm"].elements['task'].value = 'save';
				document.forms["adminForm"].submit();
			}
		}

		function displayInput(){
			document.getElementById('btn_key').style.display = 'none';
			document.getElementById('content_key').style.display = 'none';
			document.getElementById('input_key').style.display = 'inline-block';

			document.getElementById('ok').style.display = 'inline-block';
		}		
	</script>
	<style type="text/css">
		.egoi-redirect{
			font-style: italic;
	   		font-size: 14px;
	    	vertical-align: -webkit-baseline-middle;
	    	vertical-align: -moz-baseline-middle;
	    }
    	.table thead>tr>th{
    		border: none;
		    border-bottom: solid 1px #a0d0eb;
			font-weight: bold;
		}
	</style>

    <div>
        <fieldset class="adminform">	
			<table class="table table-hover">
			<?php
			if($data['apikey']!=''){

				$result = $this->egoiAccount;?>
				<form action="<?php echo JRoute::_('index.php?option=com_egoi&view=egoi'); ?>" method="post" name="egoi_key" id="egoi-form" class="form-validate">
					<input type="hidden" name="edit_sett" value="1" />
					<input type="hidden" name="api" value="1" />
					<thead>
						<tr>
							<th>
								<label for="egoi_wp_apikey"><b><?php echo JText::_('EGOI_ACCOUNT_APIKEY');?></b></label>
							</th>
							<th>	
								<span id="content_key"><?php echo $data['apikey'];?></span>
								<input id="input_key" type="text" style="width:290px;display:none;" name="apikey" size="50" value="<?php echo $data['apikey'];?>" />&nbsp;
								
								<button type="button" onclick="displayInput();" id="btn_key" class="btn btn-info">
									<?php echo JText::_('COM_EGOI_TOOLTIP_CHANGE_API_KEY'); ?>
								</button>
								<button id="ok" class="btn btn-info" style="display:none;" onclick="document.egoi_key.submit();">
									<?php echo JText::_('EGOI_SAVE_API_KEY');?>
								</button>
							</th>
						</tr>
					</thead>
				</form>
				<tbody>
					<tr>
						<th>
							<label for="egoi_jm_clientid"><?php echo JText::_('EGOI_ACCOUNT_CLIENTE_ID');?></label>
						</th>
						<td>
							<?php echo $result['CLIENTE_ID']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_companyname"><?php echo JText::_('EGOI_ACCOUNT_COMPANY_NAME');?></label>
						</th>
						<td>
							<?php echo $result['COMPANY_NAME']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_companylegalname"><?php echo JText::_('EGOI_ACCOUNT_COMPANY_LEGAL');?></label>
						</th>
						<td>
							<?php echo $result['COMPANY_LEGAL_NAME']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_companytype"><?php echo JText::_('EGOI_ACCOUNT_COMPANY_TYPE');?></label>
						</th>
						<td>
							<?php echo $result['COMPANY_TYPE']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_country"><?php echo JText::_('EGOI_ACCOUNT_COUNTRY');?></label>
						</th>
						<td>
							<?php echo $result['COUNTRY']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_state"><?php echo JText::_('EGOI_ACCOUNT_STATE');?></label>
						</th>
						<td>
							<?php echo $result['STATE']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_city"><?php echo JText::_('EGOI_ACCOUNT_CITY');?></label>
						</th>
						<td>
							<?php echo $result['CITY']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_zip"><?php echo JText::_('EGOI_ACCOUNT_ZIP');?></label>
						</th>
						<td>
							<?php echo $result['ADDRESS']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_address"><?php echo JText::_('EGOI_ACCOUNT_ADDRESS');?></label>
						</th>
						<td>
							<?php echo $result['ZIP_CODE']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_website">Website</label>
						</th>
						<td>
							<?php echo $result['WEBSITE']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_signupdate"><?php echo JText::_('EGOI_ACCOUNT_SIGNUP_DATE');?></label>
						</th>
						<td>
							<?php echo $result['SIGNUP_DATE']; ?>
						</td>
					</tr>
					<tr>
						<th>
							<label for="egoi_jm_credits"><?php echo JText::_('EGOI_ACCOUNT_CREDITS');?></label>
						</th>
						<td>
							<?php echo $result['CREDITS']; ?>
						</td>
					</tr>
				</tbody><?php 

			}else{ ?>

				<form action="<?php echo JRoute::_('index.php?option=com_egoi&view=egoi');?>" method="post" name="adminForm" id="egoi-form" class="form-validate">
					<tr>
						<td colspan="2"><b><?php echo JText::_('COM_EGOI_SECTION_LABEL_API_KEY');?></b></td>
					</tr>
					<tr>
						<td width="40%"><?php echo JText::_('COM_EGOI_DATA_LABEL_API_KEY_TOOLTIP');?></td>
						<td>
							<input type="text" name="apikey" size="50" style="width: 40%" value="<?php echo $data['apikey'];?>" required />&nbsp;
							<input type="submit" name="submit_egoi" value="Save Changes" class="btn btn-success" style="margin-bottom: 10px;">
							<input type="hidden" name="edit_sett" value="1" />
							<input type="hidden" name="api" value="1" />
						</td>
					</tr><?php echo JHtml::_('form.token');?>

				</form><?php

			}?>
			</table>

        </fieldset>
    </div>

    
    <div class="clr"></div>
