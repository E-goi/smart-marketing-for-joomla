<?php
/**
 * @copyright	Copyright (C) 2016 E-goi, All rights reserved.
 * @license		MIT License
 */

// No direct access
defined('_JEXEC') or die;

if (!class_exists( 'EgoiUtil' )) {
	require(JPATH_ROOT . DIRECTORY_SEPARATOR . 'libraries' . DIRECTORY_SEPARATOR . 'egoi' . DIRECTORY_SEPARATOR . 'EgoiApi' . DIRECTORY_SEPARATOR . 'egoi.php');
}

if (!class_exists('EgoiModelEgoi')) {
	require (JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_egoi' . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'egoi.php');
}

/**
 * Smart Marketing for Joomla plugin
 *
 * @package		Plugin
 * @subpackage	User
 */
class plgUserEgoi extends JPlugin {

	private $egoiModel;

	public function onUserAfterSave($user, $isnew, $success, $msg) {
		
		if (!$success) {
			return;
		}

		$configData = $this->getConfig();
		$sync = $configData->sync;
		$group = $configData->groups;

		if($sync){

			$this->egoiModel = new EgoiModelEgoi();

			$egoiUtil = new EgoiUtil();
			$email = $user['email'];
			$name = explode(' ', $user['name']);
			$username = $user['username'];

			if((!$group) || in_array($group, $user['groups'])){

				$data = array(
					'first_name' => $name[0] ? $name[0] : $user['name'],
					'last_name' => $name[1] ? $name[1] : $user['name'],
					'status' => 1,
				);

				$extra = $egoiUtil->getExtraFields(array('apikey' => $configData->apikey, 'listID' => $configData->list));
				foreach ($extra['extra_fields'] as $key_extra => $extra) {
					$data['extra_'.$key_extra] = '';
				}

				foreach($data as $key => $value){
					$row_new_value = $this->egoiModel->getFieldMap($key);
					$jm = $row_new_value->jm;
					if($row_new_value->id){
						$data[$row_new_value->egoi] = $user[$jm];
					}
				}

				$data['apikey'] = $configData->apikey;
				$data['listID'] = $configData->list;
				$data['email'] = $email;
				
				$egoiUtil->publishSubscriber($data);
			}
		}
	}

	public function onUserAfterDelete($user, $success, $msg){

		if (!$success) {
			return;
		}

		$configData = $this->getConfig();
		$sync = $configData->sync;
		$group = $configData->groups;

		if($sync){

			$email = $user['email'];
			$name = $user['name'];
			$username = $user['username'];

			if((!$group) || in_array($group, $user['groups'])){

				$data = array(
					'apikey' => $configData->apikey,
					'listID' => $configData->list,
					'subscriber' => $email
				);

				$egoiUtil = new EgoiUtil();
				$result = $egoiUtil->removeSubscriber($data);
			}
		}
	}
	
	public function getConfig() {
		
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		 
		$query->select($db->quoteName(array('apikey', 'addsubscribe_myaccounts', 'sync', 'te', 'list', 'groups')));
		$query->from($db->quoteName('#__egoi'));

		$db->setQuery($query);
		$userfield = $db->loadObject();
		
		return $userfield;
	}
}