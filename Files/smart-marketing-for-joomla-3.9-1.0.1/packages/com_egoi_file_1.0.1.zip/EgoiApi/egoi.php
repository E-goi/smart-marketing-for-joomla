<?php
/**
 *
 * Egoi helper
 *
 * @package    Includes
 * @subpackage Egoi
 * @author E-goi
 * @link https://www.e-goi.com
 * @copyright Copyright (c) 2020 E-goi. All rights reserved.
 * @license MIT Licence
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

set_include_path(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'egoi' . PATH_SEPARATOR . get_include_path());

if (!class_exists('EgoiApiFactory')) {
    require('Egoi' . DIRECTORY_SEPARATOR . 'Factory.php');
}

/**
 * Helper class for E-goi
 *
 * For information on E-goi API usage, please visit the API documentation, at: http://www.e-goi.com/en/recursos/api/
 *
 * @package        Libraries
 * @subpackage    E-goi
 * @author        E-goi
 */
class EgoiUtil
{

    /**
     * @var string
     */
    protected $pluginKey = "72ea3b4021b07c3c6e0d5dd0f4badbcb";

    /**
     * @param $params
     * @return mixed
     * @throws Zend_XmlRpc_Client_FaultException
     */
    function setupCallBackAPI($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $apiKey = $this->configData[$this->columnIndexes['apikey']];
        $list = $this->configData[$this->columnIndexes['list']];

        require_once JPATH_ROOT . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'egoi' . DIRECTORY_SEPARATOR . 'Zend' . DIRECTORY_SEPARATOR . 'XmlRpc' . DIRECTORY_SEPARATOR . 'Client.php';

        $client = new Zend_XmlRpc_Client('http://api.e-goi.com/v2/xmlrpc.php');
        return $result = $client->call('editApiCallback', array($params));
    }

    /**
     * @param $params
     * @return array|mixed
     */
    function createListEgoi($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;

        return $result = $api->createList($params);
    }

    /**
     * @param $params
     * @return array|mixed
     */
    function updateListEgoi($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;

        return $result = $api->updateList($params);
    }

    function getListsFromEgoi($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;
        $result = $api->getLists($params);

        return $result;
    }

    function getClientEgoi($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;
        $result = $api->getClientData($params);

        return $result;
    }

    function publishBulk($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;

        return $result = $api->addSubscriberBulk($params);
    }

    function getSubscriber($params, $option = false)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;
        if ($option) {
            $params['subscriber'] = 'all_subscribers';
        }

        return $result = $api->subscriberData($params);
    }


    function getAllSubscribers($params, $start = 0)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;
        $params['subscriber'] = 'all_subscribers';
        $params['limit'] = 1000;
        $params['start'] = $start;

        return $result = $api->subscriberData($params);
    }

    function publishSubscriber($params, $option = false)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;

        $result = $api->addSubscriber($params);

        if ($result['ERROR'] && $result['ERROR'] == 'EMAIL_ALREADY_EXISTS') {
            if ($option) {
                //print($result['ERROR']);
                //return(0);
                print('<span class="alert alert-danger">Subscriber Already exists!</span>');
                exit;
            }
            unset($params['status']);
            $params['subscriber'] = $params['email'];
            $result = $api->editSubscriber($params);
        }

        return $result;
    }

    function removeSubscriber($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;
        $result = $api->removeSubscriber($params);

        return $result;
    }

    function getForms($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;
        $result = $api->getForms($params);

        return $result;
    }

    function getExtraFields($params)
    {

        $api = EgoiApiFactory::getApi(Protocol::XmlRpc);
        $params['plugin_key'] = $this->pluginKey;
        $result = $api->getExtraFields($params);

        return $result;
    }
}

