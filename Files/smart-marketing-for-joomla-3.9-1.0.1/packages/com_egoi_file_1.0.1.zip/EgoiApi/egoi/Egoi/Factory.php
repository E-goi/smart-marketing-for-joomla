<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * @copyright	Copyright (C) 2016 E-goi, All rights reserved.
 * @license		MIT License
 */

if (!defined("EgoiApiFactory")) {
	define("EgoiApiFactory",0);
	
	require_once "Api.php";
	require_once "RestImpl.php";
	require_once "SoapImpl.php";
	require_once "XmlRpcImpl.php";
	
	abstract class EgoiApiFactory {
	
		public static function getApi($protocol) {
			switch($protocol) {
				case Protocol::Rest:
					return new EgoiApiRestImpl();
				case Protocol::Soap;
					return new EgoiApiSoapImpl();
				case Protocol::XmlRpc:
					return new EgoiApiXmlRpcImpl();
			}
		}
	
	}
	
}
?>