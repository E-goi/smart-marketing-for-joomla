<?php

/**
 * @version     1.0.1
 * @package     mod_egoi
 * @copyright   Copyright (C) 2016. Todos os direitos reservados.
 * @license     GNU General Public License versão 2 ou posterior; consulte o arquivo License. txt
 * @author      E-goi
 */

// No direct access
defined('_JEXEC') or die;
