<?php

/**
 * Smart Marketing for Joomla Module
 * 
 * @package    Joomla.Egoi
 * @subpackage Modules
 * @license        GNU/GPL, see LICENSE.php
 * mod_egoi is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// No direct access
defined('_JEXEC' ) or die;

// Include the syndicate functions only once
require_once dirname(__FILE__) . '/helper.php';

$result = ModEgoiHelper::processForm($_POST);

echo "<style>
    #load{
        background: url('//hulk-games.com/themes/happywheels_v2//resources/img/loading.gif') no-repeat;
        width: 100%;
        height: 40px;
        background-size: 50px;
    }</style>";

// Instantiate global document object
$doc = JFactory::getDocument();
$loadJquery = $params->get('loadJquery', 1);
// Load jQuery
if ($loadJquery == '1') {
	$doc->addScript('//code.jquery.com/jquery-latest.min.js');
}
$js = <<<JS
    (function ($) {
        $(document).on('click', 'input#egoi_submit', function () {
            $("#load").show();
            var form = $('#egoi_subscribe');
            var formData = $(form).serialize();

            $.ajax({
                type: 'POST',
                data: formData,
                success: function (response) {
                    $("#load").hide();
                    $('#egoi_result').html(response);
                    $(form).find("input[type=text], input[type=email]").val("");
                },
                error: function(response) {
                    $("#load").hide();
                    $('#egoi_result').html('');
                }
            });
            return false;
        });
    })(jQuery);
JS;

$doc->addScriptDeclaration($js);
$fields = ModEgoiHelper::getFields($params);
$form_type = $fields[0]->form_type;

$enc_content = $fields[0]->content;
$show = $fields[0]->show_title;
if($show){
	echo $title = $fields[0]->form_title;
}
$content = ModEgoiHelper::decode($enc_content);

//require(JModuleHelper::getLayoutPath('mod_egoi'));
