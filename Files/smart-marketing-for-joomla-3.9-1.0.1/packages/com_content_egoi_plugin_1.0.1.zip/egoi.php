<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Content.egoi
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     MIT License
 */

defined('_JEXEC') or die;

/**
 * E-goi Front Office Hooks plugin class.
 *
 * @since  0.0.1
 */
class PlgContentEgoi extends JPlugin
{

    /**
     * @return string
     */
	public function onContentAfterDisplay(){
		
		$db = JFactory::getDbo();
		$sql = "SELECT * FROM `#__egoi_forms` WHERE area='body' and enable='1'";
		$db->setQuery($sql);
		$rows = $db->loadObjectList();

		if(!empty($rows)){
			return $this->decode($rows[0]->content, $rows[0]->form_type, $rows[0]->style_w, $rows[0]->style_h);
		}

	}

    /**
     * @return string
     */
	public function onContentAfterTitle(){
		
		$db = JFactory::getDbo();
		$sql = "SELECT * FROM `#__egoi_forms` WHERE area='header' and enable='1'";
		$db->setQuery($sql);
		$rows = $db->loadObjectList();

		if(!empty($rows)){
			return $this->decode($rows[0]->content, $rows[0]->form_type, $rows[0]->style_w, $rows[0]->style_h);
		}

	}

    /**
     * @param $data
     * @param $type
     * @param string $w
     * @param string $h
     * @return string
     */
	private function decode($data, $type, $w = '', $h = ''){

		if($type == 'iframe'){
			$url = explode(' - ', base64_decode($data));
			return html_entity_decode('<iframe src="//'.$url[1].'" style="border: 0 none; width:'.$w.'px; height:'.$h.'px;" onload="window.parent.parent.scrollTo(0,0);"></iframe>');
		}
		return html_entity_decode(base64_decode($data));
	}

}
